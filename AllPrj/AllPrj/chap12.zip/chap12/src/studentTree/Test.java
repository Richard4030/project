package studentTree;

import org.eclipse.jface.viewers.TreeNode;

public class Test extends TreeNode {

	public Test(Object value) {
		super(value);
		// TODO Auto-generated constructor stub
	}

}
